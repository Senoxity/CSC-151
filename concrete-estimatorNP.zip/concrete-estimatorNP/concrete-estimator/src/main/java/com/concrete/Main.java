package com.concrete;

import com.concrete.ui.EstimatorApp;

/**
 * Concrete Pad Construction Estimator
 * Entry point for the application.
 */
public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            EstimatorApp app = new EstimatorApp();
            app.setVisible(true);
        });
    }
}
