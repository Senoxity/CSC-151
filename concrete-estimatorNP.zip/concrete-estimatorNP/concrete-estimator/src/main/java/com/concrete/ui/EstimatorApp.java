package com.concrete.ui;

import com.concrete.model.Project;
import com.concrete.model.Project.SlabType;
import com.concrete.service.CsvService;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.*;
import javax.swing.table.*;

/**
 * Concrete Pad Construction Estimator — v3
 * New palette from user palette (4F7CAC / C0E0DE / 162521 / 3C474B / FF4000).
 * Full dark mode coverage: tabs, scrollbars, borders, table.
 * Exports to imports_exports/ subfolder.
 * CSV import on Saved Estimates tab.
 */
public class EstimatorApp extends JFrame {

    // ==========================================================================
    // PALETTE — from new_app_palette.png
    //   4F7CAC  Steel blue        → primary / blue accent
    //   C0E0DE  Pale teal         → light BG tint, subtle highlights
    //   162521  Very dark green   → dark mode deep background
    //   3C474B  Dark slate        → dark mode card / mid-dark surface
    //   FF4000  Vivid orange-red  → accent / CTA (replaces old amber)
    // ==========================================================================

    private boolean darkMode = false;

    // ── Light theme ───────────────────────────────────────────────────────────
    // Primary action blue: 4F7CAC
    // Accent / CTA red-orange: FF4000
    // BG: tinted off-white derived from C0E0DE (very light teal)
    // Card: pure white
    // Borders: soft teal-grey
    private static final Color L_PRIMARY   = new Color(0x4F7CAC);
    private static final Color L_ACCENT    = new Color(0xFF4000);
    private static final Color L_BG        = new Color(0xEDF5F5);  // very light C0E0DE tint
    private static final Color L_CARD      = Color.WHITE;
    private static final Color L_SUCCESS   = new Color(0x2E8B57);  // sea green
    private static final Color L_TEXT      = new Color(0x162521);  // darkest palette color = body text
    private static final Color L_TEXT_MED  = new Color(0x3C474B);  // slate = medium text
    private static final Color L_BORDER    = new Color(0xC0E0DE);  // pale teal = borders
    private static final Color L_INPUT     = Color.WHITE;
    private static final Color L_TOPBAR    = new Color(0x1E3A52);  // dark navy derived from 4F7CAC
    private static final Color L_MUTED     = new Color(0x7A9BAD);  // muted blue-grey
    private static final Color L_TAB_SEL   = new Color(0x4F7CAC);  // selected tab = primary
    private static final Color L_TAB_BG    = new Color(0xDDEEED);  // unselected tab BG
    private static final Color L_SCROLL    = new Color(0xB0CECE);  // scrollbar thumb

    // ── Dark theme ────────────────────────────────────────────────────────────
    // Deep BG: 162521  Card: 3C474B  Accent: FF4000  Blue: 4F7CAC lighter
    private static final Color D_PRIMARY   = new Color(0x7AAFD4);  // lighter 4F7CAC for dark
    private static final Color D_ACCENT    = new Color(0xFF4000);
    private static final Color D_BG        = new Color(0x162521);  // deepest palette = dark BG
    private static final Color D_CARD      = new Color(0x243130);  // slightly lighter than BG
    private static final Color D_SUCCESS   = new Color(0x3CB371);
    private static final Color D_TEXT      = new Color(0xC0E0DE);  // pale teal = light text on dark
    private static final Color D_TEXT_MED  = new Color(0x7AAEB0);  // muted teal-grey
    private static final Color D_BORDER    = new Color(0x3C474B);  // dark slate = borders
    private static final Color D_INPUT     = new Color(0x1E2E2C);  // very dark input bg
    private static final Color D_TOPBAR    = new Color(0x0E1A18);  // darkest topbar
    private static final Color D_MUTED     = new Color(0x5C7070);
    private static final Color D_TAB_SEL   = new Color(0x3C474B);  // selected tab on dark
    private static final Color D_TAB_BG    = new Color(0x1E2B29);  // unselected tab on dark
    private static final Color D_SCROLL    = new Color(0x3C474B);  // scrollbar thumb dark

    // Theme accessors
    private Color PRIMARY()  { return darkMode ? D_PRIMARY  : L_PRIMARY;  }
    private Color ACCENT()   { return darkMode ? D_ACCENT   : L_ACCENT;   }
    private Color BG()       { return darkMode ? D_BG       : L_BG;       }
    private Color CARD()     { return darkMode ? D_CARD     : L_CARD;     }
    private Color SUCCESS()  { return darkMode ? D_SUCCESS  : L_SUCCESS;  }
    private Color TEXT()     { return darkMode ? D_TEXT     : L_TEXT;     }
    private Color TEXT_MED() { return darkMode ? D_TEXT_MED : L_TEXT_MED; }
    private Color BORDER()   { return darkMode ? D_BORDER   : L_BORDER;   }
    private Color INPUT_BG() { return darkMode ? D_INPUT    : L_INPUT;    }
    private Color TOPBAR()   { return darkMode ? D_TOPBAR   : L_TOPBAR;   }
    private Color MUTED()    { return darkMode ? D_MUTED    : L_MUTED;    }
    private Color TAB_SEL()  { return darkMode ? D_TAB_SEL  : L_TAB_SEL;  }
    private Color TAB_BG()   { return darkMode ? D_TAB_BG   : L_TAB_BG;   }
    private Color SCROLL()   { return darkMode ? D_SCROLL   : L_SCROLL;   }

    // ── Fonts ─────────────────────────────────────────────────────────────────
    private static final Font FNT_TITLE  = new Font("Segoe UI", Font.BOLD, 20);
    private static final Font FNT_HEAD   = new Font("Segoe UI", Font.BOLD, 13);
    private static final Font FNT_LABEL  = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FNT_INPUT  = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FNT_RESULT = new Font("Segoe UI", Font.BOLD, 13);
    private static final Font FNT_SMALL  = new Font("Segoe UI", Font.PLAIN, 11);
    private static final Font FNT_MONO   = new Font("Consolas",  Font.PLAIN, 11);
    private static final Font FNT_CAP    = new Font("Segoe UI", Font.BOLD, 10);

    // ── State ─────────────────────────────────────────────────────────────────
    private final CsvService csvService = new CsvService();
    private final NumberFormat currFmt  = NumberFormat.getCurrencyInstance(Locale.US);
    private final NumberFormat numFmt   = NumberFormat.getNumberInstance(Locale.US);

    // Inputs
    private JTextField tfName, tfLocation, tfClient, tfDate;
    private JComboBox<SlabType> cbSlab;
    private JTextField tfLen, tfWid, tfThick, tfWaste;
    private JTextField tfEmp, tfHours, tfRate;
    private JTextField tfConcrCost, tfDiscPct, tfDiscFixed;

    // Results
    private JLabel lbArea, lbVol, lbLaborHrs;
    private JLabel lbConcrCost, lbLaborCost, lbSub, lbDisc, lbTotal;
    private JLabel lbStatus;

    // History
    private DefaultTableModel histModel;
    private JTable histTable;
    private JLabel lbHistPath;

    // UI roots
    private JPanel rootPanel;
    private JPanel topBar;
    private JTabbedPane tabs;
    private DarkToggle darkBtn;

    // ==========================================================================
    public EstimatorApp() {
        super("Concrete Pad Construction Estimator");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { onClose(); }
        });
        setMinimumSize(new Dimension(1060, 780));
        setPreferredSize(new Dimension(1190, 860));

        showWelcome();
        buildUI();
        pack();
        setLocationRelativeTo(null);
        loadHistory();
    }

    // ==========================================================================
    // WELCOME / GOODBYE
    // ==========================================================================
    private void showWelcome() {
        JDialog dlg = new JDialog(this, "Welcome", true);
        dlg.setResizable(false);

        JPanel root = new JPanel(new BorderLayout());

        // Header — uses palette topbar colour
        JPanel hdr = new JPanel(new FlowLayout(FlowLayout.LEFT, 24, 22));
        hdr.setBackground(L_TOPBAR);
        hdr.add(new JLabel(CIcon.slab(new Color(0xFF4000), 40)));
        JPanel htxt = new JPanel();
        htxt.setLayout(new BoxLayout(htxt, BoxLayout.Y_AXIS));
        htxt.setOpaque(false);
        JLabel ht = new JLabel("Concrete Pad Construction Estimator");
        ht.setFont(new Font("Segoe UI", Font.BOLD, 18));
        ht.setForeground(Color.WHITE);
        JLabel hv = new JLabel("Version 3.0 — Professional Edition");
        hv.setFont(FNT_SMALL);
        hv.setForeground(new Color(0xC0E0DE));
        htxt.add(ht); htxt.add(Box.createVerticalStrut(3)); htxt.add(hv);
        hdr.add(htxt);
        root.add(hdr, BorderLayout.NORTH);

        // Body — dark slate
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(new Color(0x243130));
        body.setBorder(new EmptyBorder(18, 28, 24, 28));
        JLabel bodyHdr = new JLabel("What you can do with this tool:");
        bodyHdr.setFont(FNT_HEAD);
        bodyHdr.setForeground(new Color(0xC0E0DE));
        bodyHdr.setAlignmentX(LEFT_ALIGNMENT);
        body.add(bodyHdr);
        body.add(Box.createVerticalStrut(10));
        String[] feats = {
            "Calculate concrete volume and material cost for any pad",
            "Estimate labor hours and total workforce cost",
            "Apply percentage or fixed-dollar discounts",
            "Choose from 6 preset slab types with auto-filled values",
            "Export estimates to imports_exports/ folder as CSV",
            "Import any compatible CSV to view in Saved Estimates",
            "Toggle dark mode from the top bar at any time"
        };
        for (String f : feats) {
            JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
            row.setOpaque(false);
            row.setAlignmentX(LEFT_ALIGNMENT);
            row.add(new JLabel(CIcon.check(new Color(0x2E8B57), 14)));
            JLabel lbl = new JLabel(f);
            lbl.setFont(FNT_LABEL);
            lbl.setForeground(new Color(0xC0E0DE));
            row.add(lbl);
            body.add(row);
        }
        body.add(Box.createVerticalStrut(20));
        JButton go = pill("Get Started  →", new Color(0xFF4000), Color.WHITE);
        go.setAlignmentX(CENTER_ALIGNMENT);
        go.addActionListener(e -> dlg.dispose());
        body.add(go);
        root.add(body, BorderLayout.CENTER);

        dlg.setContentPane(root);
        dlg.pack();
        dlg.setLocationRelativeTo(null);
        dlg.setVisible(true);
    }

    private void onClose() {
        Object[] opts = {"Exit Application", "Keep Working"};
        int r = JOptionPane.showOptionDialog(this,
            "<html><b style='font-size:13px'>Exit Concrete Pad Estimator?</b>"
            + "<br><span style='color:#666'>Unsaved estimates will be lost.</span></html>",
            "Confirm Exit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE,
            new ImageIcon(), opts, opts[1]);
        if (r == 0) showGoodbye();
    }

    private void showGoodbye() {
        JDialog dlg = new JDialog(this, "", false);
        dlg.setUndecorated(true);
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 18));
        p.setBackground(L_TOPBAR);
        p.setBorder(new LineBorder(new Color(0xFF4000), 2, true));
        p.add(new JLabel(CIcon.slab(new Color(0xFF4000), 36)));
        JPanel txt = new JPanel();
        txt.setLayout(new BoxLayout(txt, BoxLayout.Y_AXIS));
        txt.setOpaque(false);
        JLabel bye = new JLabel("Thanks for using Concrete Pad Estimator!");
        bye.setFont(FNT_HEAD); bye.setForeground(Color.WHITE);
        JLabel sub2 = new JLabel("CSV files saved to: imports_exports/");
        sub2.setFont(FNT_SMALL); sub2.setForeground(new Color(0xC0E0DE));
        txt.add(bye); txt.add(Box.createVerticalStrut(4)); txt.add(sub2);
        p.add(txt);
        dlg.setContentPane(p);
        dlg.pack();
        dlg.setLocationRelativeTo(null);
        dlg.setVisible(true);
        new Timer(1800, e -> System.exit(0)) {{ setRepeats(false); start(); }};
    }

    // ==========================================================================
    // BUILD / REBUILD UI
    // ==========================================================================
    private void buildUI() {
        rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(BG());
        setContentPane(rootPanel);

        topBar = buildTopBar();
        rootPanel.add(topBar, BorderLayout.NORTH);

        tabs = buildTabs();
        rootPanel.add(tabs, BorderLayout.CENTER);
    }

    private void rebuildUI() {
        getContentPane().removeAll();
        rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(BG());
        setContentPane(rootPanel);

        topBar = buildTopBar();
        darkBtn.setSelected(darkMode);
        rootPanel.add(topBar, BorderLayout.NORTH);

        int prevTab = tabs != null ? tabs.getSelectedIndex() : 0;
        tabs = buildTabs();
        tabs.setSelectedIndex(prevTab);
        rootPanel.add(tabs, BorderLayout.CENTER);

        loadHistory();
        revalidate();
        repaint();
    }

    // ── Top Bar ───────────────────────────────────────────────────────────────
    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(ACCENT());
                g.fillRect(0, getHeight()-3, getWidth(), 3);
            }
        };
        bar.setBackground(TOPBAR());
        bar.setBorder(new EmptyBorder(11, 22, 11, 22));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        left.setOpaque(false);
        left.add(new JLabel(CIcon.slab(ACCENT(), 26)));
        left.add(Box.createHorizontalStrut(11));
        JPanel ts = new JPanel();
        ts.setLayout(new BoxLayout(ts, BoxLayout.Y_AXIS));
        ts.setOpaque(false);
        JLabel title = new JLabel("Concrete Pad Construction Estimator");
        title.setFont(FNT_TITLE); title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Professional Cost Estimation Tool");
        sub.setFont(FNT_SMALL);
        sub.setForeground(new Color(0xC0E0DE).darker());
        ts.add(title); ts.add(sub);
        left.add(ts);
        bar.add(left, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.setOpaque(false);
        JLabel tl = new JLabel("Dark Mode");
        tl.setFont(FNT_SMALL);
        tl.setForeground(new Color(0x7AAEB0));
        darkBtn = new DarkToggle(darkMode);
        darkBtn.addActionListener(e -> { darkMode = darkBtn.isSelected(); rebuildUI(); });
        right.add(tl); right.add(darkBtn);
        bar.add(right, BorderLayout.EAST);

        return bar;
    }

    // ── Tabbed Pane — with custom UI for dark mode ────────────────────────────
    private JTabbedPane buildTabs() {
        JTabbedPane tp = new JTabbedPane(JTabbedPane.TOP) {
            @Override public void updateUI() {
                setUI(new ThemedTabbedPaneUI());
            }
        };
        tp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tp.setBackground(BG());
        tp.setForeground(TEXT());
        tp.addTab("  New Estimate  ",    CIcon.tab("calc", PRIMARY()), buildEstTab());
        tp.addTab("  Saved Estimates  ", CIcon.tab("hist", PRIMARY()), buildHistTab());
        tp.addTab("  About  ",           CIcon.tab("info", PRIMARY()), buildAboutTab());
        return tp;
    }

    // ==========================================================================
    // ESTIMATOR TAB
    // ==========================================================================
    private JPanel buildEstTab() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(BG());
        root.setBorder(new EmptyBorder(16, 18, 16, 18));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.BOTH; gc.weighty = 1.0;

        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBackground(BG());
        left.add(projectCard()); left.add(gap(10));
        left.add(workAreaCard()); left.add(gap(10));
        left.add(laborCard()); left.add(gap(10));
        left.add(costCard()); left.add(gap(10));
        left.add(actionButtons()); left.add(gap(6));

        JScrollPane ls = themedScrollPane(left);
        ls.setBorder(BorderFactory.createEmptyBorder());

        gc.gridx=0; gc.weightx=0.57; root.add(ls, gc);
        gc.gridx=1; gc.weightx=0.0; gc.fill=GridBagConstraints.NONE;
        root.add(Box.createHorizontalStrut(14), gc);
        gc.gridx=2; gc.weightx=0.43; gc.fill=GridBagConstraints.BOTH;
        root.add(resultsPanel(), gc);
        return root;
    }

    private JPanel projectCard() {
        JPanel inner = grid();
        tfName     = tf("My Concrete Pad");
        tfLocation = tf("123 Main St, City, ST");
        tfClient   = tf("Client Name");
        tfDate     = tf(java.time.LocalDate.now().toString());
        cbSlab     = new JComboBox<>(SlabType.values());
        styleCombo(cbSlab);
        cbSlab.addActionListener(e -> slabChanged());
        row(inner,"Project Name:", tfName);
        row(inner,"Location:", tfLocation);
        row(inner,"Client Name:", tfClient);
        row(inner,"Date:", tfDate);
        row(inner,"Slab Type:", cbSlab);
        return card(inner, "Project Information", "proj");
    }

    private JPanel workAreaCard() {
        JPanel inner = grid();
        tfLen=tf("20"); tfWid=tf("30"); tfThick=tf("4"); tfWaste=tf("5");
        row(inner,"Length (ft):", tfLen); row(inner,"Width (ft):", tfWid);
        row(inner,"Thickness (inches):", tfThick); row(inner,"Waste % (optional):", tfWaste);
        return card(inner, "Work Area", "ruler");
    }

    private JPanel laborCard() {
        JPanel inner = grid();
        tfEmp=tf("4"); tfHours=tf("8"); tfRate=tf("35");
        row(inner,"Number of Employees:", tfEmp);
        row(inner,"Hours per Employee:", tfHours);
        row(inner,"Labor Rate ($/hr):", tfRate);
        return card(inner, "Labor Estimation", "labor");
    }

    private JPanel costCard() {
        JPanel inner = grid();
        tfConcrCost=tf("130"); tfDiscPct=tf("0"); tfDiscFixed=tf("0");
        row(inner,"Concrete ($/cu yd):", tfConcrCost);
        row(inner,"Discount %:", tfDiscPct);
        row(inner,"Fixed Discount ($):", tfDiscFixed);
        return card(inner, "Cost & Discounts", "dollar");
    }

    private JPanel actionButtons() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);
        JPanel row = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        row.setOpaque(false);

        // Calculate = accent (orange-red) on dark text
        JButton btnCalc  = pill("Calculate",  ACCENT(),   darkMode ? Color.WHITE : new Color(0x162521), CIcon.calcI(darkMode ? Color.WHITE : new Color(0x162521)));
        // Save = primary blue
        JButton btnSave  = pill("Save to CSV",PRIMARY(),  Color.WHITE, CIcon.saveI(Color.WHITE));
        // Clear = muted slate
        JButton btnClear = pill("Clear Form", new Color(0x3C474B), new Color(0xC0E0DE), CIcon.clearI(new Color(0xC0E0DE)));

        btnCalc.addActionListener(e -> calculate());
        btnSave.addActionListener(e -> saveCSV());
        btnClear.addActionListener(e -> clearForm());

        row.add(btnCalc); row.add(btnSave); row.add(btnClear);

        lbStatus = new JLabel(" ");
        lbStatus.setFont(FNT_SMALL); lbStatus.setForeground(SUCCESS());
        lbStatus.setHorizontalAlignment(SwingConstants.CENTER);

        outer.add(row, BorderLayout.CENTER);
        outer.add(lbStatus, BorderLayout.SOUTH);
        return outer;
    }

    private JPanel resultsPanel() {
        JPanel outer = new JPanel(new BorderLayout(0, 10));
        outer.setBackground(BG());

        JLabel hdr = new JLabel("  Estimate Summary");
        hdr.setFont(FNT_HEAD); hdr.setForeground(PRIMARY());
        hdr.setIcon(CIcon.summI(PRIMARY()));
        outer.add(hdr, BorderLayout.NORTH);

        JPanel box = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD()); g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                g2.setColor(BORDER()); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,12,12);
                // Left accent bar — use ACCENT colour (orange-red)
                g2.setColor(ACCENT());
                g2.fillRoundRect(0, 14, 4, getHeight()-28, 4, 4);
                g2.dispose();
            }
        };
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        box.setOpaque(false);
        box.setBorder(new EmptyBorder(16, 20, 16, 16));

        capLabel(box, "MEASUREMENTS");
        lbArea     = rrow(box, "Work Area",         "—", "sq ft");
        lbVol      = rrow(box, "Concrete Volume",   "—", "cu yd");
        lbLaborHrs = rrow(box, "Total Labor Hours", "—", "hrs");
        divLine(box);
        capLabel(box, "COSTS");
        lbConcrCost = rrow(box, "Concrete Material", "—", "");
        lbLaborCost = rrow(box, "Labor Cost",        "—", "");
        lbSub       = rrowBold(box, "Subtotal",      "—");
        divLine(box);
        lbDisc = rrow(box, "Discount Applied", "—", "");
        lbDisc.setForeground(SUCCESS());
        box.add(gap(10));

        // Grand total banner — PRIMARY blue gradient
        JPanel banner = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0,0, PRIMARY(), getWidth(), 0, PRIMARY().darker()));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.dispose();
            }
        };
        banner.setOpaque(false);
        banner.setBorder(new EmptyBorder(12,14,12,14));
        banner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));

        JPanel bLeft = new JPanel();
        bLeft.setLayout(new BoxLayout(bLeft, BoxLayout.Y_AXIS));
        bLeft.setOpaque(false);
        JLabel bTag = new JLabel("TOTAL PROJECT COST");
        bTag.setFont(FNT_CAP); bTag.setForeground(new Color(0xC0E0DE)); bTag.setAlignmentX(LEFT_ALIGNMENT);
        JLabel bSub = new JLabel("All costs and discounts included");
        bSub.setFont(FNT_SMALL); bSub.setForeground(new Color(0xC0E0DE)); bSub.setAlignmentX(LEFT_ALIGNMENT);
        bLeft.add(bTag); bLeft.add(bSub);

        lbTotal = new JLabel("—");
        lbTotal.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lbTotal.setForeground(Color.WHITE);

        banner.add(bLeft, BorderLayout.WEST);
        banner.add(lbTotal, BorderLayout.EAST);
        box.add(banner);
        outer.add(box, BorderLayout.CENTER);

        JLabel note = new JLabel("<html><i>* Volume includes waste %. Total applies all discounts.</i></html>");
        note.setFont(FNT_SMALL); note.setForeground(MUTED());
        outer.add(note, BorderLayout.SOUTH);
        return outer;
    }

    // ==========================================================================
    // HISTORY TAB — with Import CSV button
    // ==========================================================================
    private JPanel buildHistTab() {
        JPanel p = new JPanel(new BorderLayout(8, 10));
        p.setBackground(BG());
        p.setBorder(new EmptyBorder(14, 18, 14, 18));

        // Header
        JLabel hdr = new JLabel("  Saved Estimates");
        hdr.setFont(new Font("Segoe UI", Font.BOLD, 15));
        hdr.setForeground(PRIMARY());
        hdr.setIcon(CIcon.tab("hist", PRIMARY()));
        hdr.setBorder(new EmptyBorder(0, 0, 8, 0));
        p.add(hdr, BorderLayout.NORTH);

        // Table
        String[] cols = {"Date","Project","Location","Slab Type",
                         "Area (sqft)","Volume (cuyd)","Employees",
                         "Labor Hrs","Concrete Cost","Labor Cost","Total Cost"};
        histModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        histTable = new JTable(histModel);
        histTable.setFont(FNT_LABEL);
        histTable.setRowHeight(28);
        histTable.setIntercellSpacing(new Dimension(12, 0));
        histTable.getTableHeader().setFont(FNT_HEAD);
        histTable.getTableHeader().setBackground(darkMode ? D_BORDER : L_PRIMARY);
        histTable.getTableHeader().setForeground(Color.WHITE);
        histTable.getTableHeader().setPreferredSize(new Dimension(0, 32));
        histTable.setBackground(CARD());
        histTable.setForeground(TEXT());
        histTable.setGridColor(BORDER());
        histTable.setSelectionBackground(darkMode ? new Color(0x3C5A6A) : new Color(0xC0DCED));
        histTable.setSelectionForeground(TEXT());
        histTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        histTable.setShowGrid(true);

        Color altRow = darkMode ? new Color(0x1E2E2C) : new Color(0xEDF5F5);
        histTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                setFont(FNT_LABEL);
                if (!sel) { setBackground(row%2==0 ? CARD() : altRow); setForeground(TEXT()); }
                setBorder(new EmptyBorder(0, 8, 0, 8));
                return this;
            }
        });
        int[] ws = {145,120,120,120,80,90,70,80,112,105,110};
        for (int i=0; i<ws.length && i<histTable.getColumnCount(); i++)
            histTable.getColumnModel().getColumn(i).setPreferredWidth(ws[i]);

        JScrollPane sc = themedScrollPane(histTable);
        sc.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        sc.getViewport().setBackground(CARD());
        sc.setBorder(new LineBorder(BORDER(), 1, true));
        p.add(sc, BorderLayout.CENTER);

        // South bar: path label + Import + Refresh buttons
        JPanel south = new JPanel(new BorderLayout(8, 0));
        south.setBackground(BG());
        south.setBorder(new EmptyBorder(6, 0, 0, 0));

        lbHistPath = new JLabel("Folder: " + csvService.getIoDirPath());
        lbHistPath.setFont(FNT_MONO);
        lbHistPath.setForeground(MUTED());

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setOpaque(false);

        JButton btnImport  = pill("Import CSV",  new Color(0x3C474B), new Color(0xC0E0DE), CIcon.importI(new Color(0xC0E0DE)));
        JButton btnRefresh = pill("Refresh",      PRIMARY(), Color.WHITE,                  CIcon.refreshI(Color.WHITE));
        btnImport.addActionListener(e -> importCSV());
        btnRefresh.addActionListener(e -> loadHistory());

        btnRow.add(btnImport);
        btnRow.add(btnRefresh);

        south.add(lbHistPath, BorderLayout.WEST);
        south.add(btnRow, BorderLayout.EAST);
        p.add(south, BorderLayout.SOUTH);
        return p;
    }

    // ==========================================================================
    // ABOUT TAB
    // ==========================================================================
    private JPanel buildAboutTab() {
        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(BG());
        outer.setBorder(new EmptyBorder(28, 0, 28, 0));

        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD()); g2.fillRoundRect(0,0,getWidth(),getHeight(),14,14);
                g2.setColor(BORDER()); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,14,14);
                g2.dispose();
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(36, 44, 36, 44));
        card.setMaximumSize(new Dimension(700, Integer.MAX_VALUE));

        JPanel logo = new JPanel(new FlowLayout(FlowLayout.CENTER));
        logo.setOpaque(false);
        logo.add(new JLabel(CIcon.slab(PRIMARY(), 56)));
        card.add(logo); card.add(gap(10));

        card.add(cLabel("Concrete Pad Construction Estimator", new Font("Segoe UI",Font.BOLD,20), TEXT()));
        card.add(gap(3));
        card.add(cLabel("Version 3.0 — Professional Edition", FNT_SMALL, MUTED()));
        card.add(gap(26));

        aboutDivider(card, "ABOUT THIS APPLICATION");
        card.add(gap(10));
        JLabel desc = new JLabel("<html><div style='text-align:center;width:480px'>"
            + "Designed for contractors, project managers, and estimators who need fast, "
            + "accurate cost estimates for concrete pad construction. Enter project details, "
            + "dimensions, and labor information to instantly generate a detailed cost breakdown "
            + "exportable as CSV for your records."
            + "</div></html>");
        desc.setFont(FNT_LABEL); desc.setForeground(TEXT_MED()); desc.setAlignmentX(CENTER_ALIGNMENT);
        card.add(desc); card.add(gap(24));

        aboutDivider(card, "FEATURES");
        card.add(gap(10));
        Object[][] feats = {
            {"Project Details",    "Capture project name, client, location, and date"},
            {"Slab Type Presets",  "6 preset types auto-fill thickness and material cost"},
            {"Volume Calculator",  "Computes concrete in cu yd with waste factor"},
            {"Labor Estimation",   "Employees × hours × hourly rate = total labor cost"},
            {"Discount System",    "Apply a % discount, fixed discount, or both"},
            {"CSV Export",         "Saves to imports_exports/ folder automatically"},
            {"CSV Import",         "Import any compatible estimates CSV to view history"},
            {"Saved Estimates",    "Browse every recorded estimate in the history table"},
            {"Dark Mode",          "Toggle light/dark theme from the header bar"},
        };
        for (Object[] f : feats) {
            JPanel row = new JPanel(new BorderLayout(10, 0));
            row.setOpaque(false);
            row.setMaximumSize(new Dimension(540, 28));
            row.setBorder(new EmptyBorder(2,0,2,0));
            row.setAlignmentX(CENTER_ALIGNMENT);
            JLabel dot  = new JLabel(CIcon.check(SUCCESS(), 14));
            JLabel name = new JLabel((String)f[0]);
            name.setFont(new Font("Segoe UI",Font.BOLD,12)); name.setForeground(TEXT());
            name.setPreferredSize(new Dimension(155,20));
            JLabel det  = new JLabel((String)f[1]);
            det.setFont(FNT_LABEL); det.setForeground(TEXT_MED());
            row.add(dot, BorderLayout.WEST); row.add(name, BorderLayout.CENTER); row.add(det, BorderLayout.EAST);
            card.add(row);
        }
        card.add(gap(24));

        aboutDivider(card, "HOW TO USE");
        card.add(gap(10));
        String[] steps = {
            "1.  Fill in Project Information and choose a Slab Type.",
            "2.  Enter work area dimensions (length × width in feet).",
            "3.  Adjust thickness, waste %, and concrete cost per cu yd.",
            "4.  Enter labor details: employees, hours, and hourly rate.",
            "5.  Optionally apply a percentage and/or fixed dollar discount.",
            "6.  Click Calculate to preview the estimate.",
            "7.  Click Save to CSV — file appears in imports_exports/ folder.",
            "8.  Use Import CSV on the Saved Estimates tab to load any CSV."
        };
        for (String s : steps) {
            JLabel lbl = new JLabel(s);
            lbl.setFont(FNT_LABEL); lbl.setForeground(TEXT()); lbl.setAlignmentX(CENTER_ALIGNMENT);
            lbl.setBorder(new EmptyBorder(2,0,2,0)); card.add(lbl);
        }
        card.add(gap(24));

        aboutDivider(card, "FORMULA REFERENCE");
        card.add(gap(10));
        Object[][] fmls = {
            {"Area",          "Length (ft) × Width (ft)  =  sq ft"},
            {"Volume",        "(Area × Thickness ÷ 12) × (1 + Waste%) ÷ 27  =  cu yd"},
            {"Concrete Cost", "Volume (cu yd) × Cost per cu yd"},
            {"Labor Cost",    "Employees × Hours per Employee × Hourly Rate"},
            {"Discount",      "(Subtotal × Discount%) + Fixed Discount"},
            {"Total",         "Concrete Cost + Labor Cost − Discount Amount"},
        };
        for (Object[] fm : fmls) {
            JPanel row = new JPanel(new BorderLayout(12,0));
            row.setOpaque(false); row.setMaximumSize(new Dimension(560,26));
            row.setBorder(new EmptyBorder(2,0,2,0)); row.setAlignmentX(CENTER_ALIGNMENT);
            JLabel k = new JLabel((String)fm[0]);
            k.setFont(new Font("Segoe UI",Font.BOLD,12)); k.setForeground(PRIMARY()); k.setPreferredSize(new Dimension(115,18));
            JLabel v = new JLabel((String)fm[1]);
            v.setFont(FNT_MONO); v.setForeground(TEXT_MED());
            row.add(k, BorderLayout.WEST); row.add(v, BorderLayout.CENTER);
            card.add(row);
        }
        card.add(gap(28));
        card.add(cLabel("© 2025 Concrete Pad Estimator — All rights reserved.", FNT_SMALL, MUTED()));

        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx=0; gc.gridy=0; gc.weightx=1; gc.weighty=1;
        gc.fill=GridBagConstraints.NONE; gc.anchor=GridBagConstraints.CENTER;
        outer.add(card, gc);

        JScrollPane sc = themedScrollPane(outer);
        sc.setBorder(BorderFactory.createEmptyBorder());
        sc.getVerticalScrollBar().setUnitIncrement(16);
        JPanel w = new JPanel(new BorderLayout());
        w.setBackground(BG()); w.add(sc, BorderLayout.CENTER);
        return w;
    }

    // ==========================================================================
    // LOGIC
    // ==========================================================================
    private void slabChanged() {
        SlabType st = (SlabType) cbSlab.getSelectedItem();
        if (st != null) {
            tfThick.setText(String.valueOf(st.getDefaultThicknessInches()));
            tfConcrCost.setText(String.valueOf(st.getDefaultCostPerCubicYard()));
        }
    }

    private void calculate() {
        try { updateResults(buildProject()); lbStatus.setText(" "); }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers.\n" + ex.getMessage(),
                "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveCSV() {
        try {
            Project p = buildProject();
            updateResults(p);
            csvService.saveEstimate(p);
            csvService.saveLaborLog(p);
            loadHistory();

            lbStatus.setForeground(SUCCESS());
            lbStatus.setText("✔  Estimate saved to imports_exports/ folder.");
            new Timer(4000, e -> lbStatus.setText(" ")) {{ setRepeats(false); start(); }};

            tabs.setSelectedIndex(1);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers.\n" + ex.getMessage(),
                "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            lbStatus.setForeground(Color.RED);
            lbStatus.setText("✘  Error: " + ex.getMessage());
        }
    }

    /** Opens a file chooser and imports selected CSV into the history table. */
    private void importCSV() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Import Estimates CSV");
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files (*.csv)", "csv"));
        chooser.setCurrentDirectory(new File(csvService.getIoDirPath()));

        // Style the chooser slightly for dark mode (best-effort)
        if (darkMode) {
            chooser.setBackground(D_CARD);
            chooser.setForeground(D_TEXT);
        }

        int result = chooser.showOpenDialog(this);
        if (result != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();
        if (file == null || !file.exists()) return;

        try {
            List<String[]> rows = csvService.importEstimatesFromFile(file);
            if (rows.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "No data rows found in the selected file.\n"
                    + "Make sure it is a valid estimates CSV exported by this application.",
                    "Import: No Data", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Merge into table — add rows that have enough columns
            int added = 0;
            for (String[] r : rows) {
                if (r.length >= 22) {
                    histModel.addRow(new Object[]{r[0],r[1],r[2],r[4],r[9],r[10],r[11],r[13],r[16],r[17],r[21]});
                    added++;
                } else if (r.length >= 11) {
                    // Partial row — still show what we have, pad with empty strings
                    String[] padded = new String[22];
                    java.util.Arrays.fill(padded, "");
                    System.arraycopy(r, 0, padded, 0, r.length);
                    histModel.addRow(new Object[]{padded[0],padded[1],padded[2],padded[4],padded[9],padded[10],padded[11],padded[13],padded[16],padded[17],padded[21]});
                    added++;
                }
            }

            if (lbHistPath != null)
                lbHistPath.setText("Imported: " + file.getName() + "  (" + added + " rows)");

            JOptionPane.showMessageDialog(this,
                "Successfully imported " + added + " row(s) from:\n" + file.getAbsolutePath(),
                "Import Successful", JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                "Failed to read file:\n" + ex.getMessage(),
                "Import Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        tfName.setText("My Concrete Pad"); tfLocation.setText(""); tfClient.setText("");
        tfDate.setText(java.time.LocalDate.now().toString());
        cbSlab.setSelectedIndex(0);
        tfLen.setText("20");  tfWid.setText("30");
        tfThick.setText("4"); tfWaste.setText("5");
        tfEmp.setText("4");   tfHours.setText("8"); tfRate.setText("35");
        tfConcrCost.setText("130"); tfDiscPct.setText("0"); tfDiscFixed.setText("0");
        for (JLabel lb : new JLabel[]{lbArea,lbVol,lbLaborHrs,lbConcrCost,lbLaborCost,lbSub,lbDisc,lbTotal})
            lb.setText("—");
        lbStatus.setText(" ");
    }

    private Project buildProject() {
        Project p = new Project();
        p.setProjectName(tfName.getText().trim()); p.setLocation(tfLocation.getText().trim());
        p.setClientName(tfClient.getText().trim()); p.setProjectDate(tfDate.getText().trim());
        p.setSlabType((SlabType) cbSlab.getSelectedItem());
        p.setLengthFt(pd(tfLen,"Length")); p.setWidthFt(pd(tfWid,"Width"));
        p.setThicknessInches(pd(tfThick,"Thickness")); p.setWastePercentage(pd(tfWaste,"Waste%"));
        p.setNumberOfEmployees((int)pd(tfEmp,"Employees")); p.setHoursPerEmployee(pd(tfHours,"Hours"));
        p.setLaborRatePerHour(pd(tfRate,"Labor Rate"));
        p.setConcreteCostPerCubicYard(pd(tfConcrCost,"Concrete Cost"));
        p.setDiscountPercentage(pd(tfDiscPct,"Discount%")); p.setFixedDiscount(pd(tfDiscFixed,"Fixed Discount"));
        return p;
    }

    private void updateResults(Project p) {
        numFmt.setMinimumFractionDigits(2); numFmt.setMaximumFractionDigits(2);
        lbArea.setText(numFmt.format(p.getAreaSqFt()));
        lbVol.setText(numFmt.format(p.getVolumeCubicYards()));
        lbLaborHrs.setText(numFmt.format(p.getTotalLaborHours()));
        lbConcrCost.setText(currFmt.format(p.getConcreteMaterialCost()));
        lbLaborCost.setText(currFmt.format(p.getLaborCost()));
        lbSub.setText(currFmt.format(p.getSubtotal()));
        lbDisc.setText("− " + currFmt.format(p.getDiscountAmount()));
        lbTotal.setText(currFmt.format(p.getTotalProjectCost()));
    }

    private void loadHistory() {
        if (histModel == null) return;
        try {
            histModel.setRowCount(0);
            for (String[] r : csvService.loadEstimates()) {
                if (r.length >= 22)
                    histModel.addRow(new Object[]{r[0],r[1],r[2],r[4],r[9],r[10],r[11],r[13],r[16],r[17],r[21]});
            }
        } catch (IOException ex) { /* no file yet — OK */ }
    }

    private double pd(JTextField tf, String name) {
        String t = tf.getText().trim();
        if (t.isEmpty()) return 0.0;
        try { return Double.parseDouble(t); }
        catch (NumberFormatException e) {
            throw new NumberFormatException("Invalid value for " + name + ": \"" + t + "\"");
        }
    }

    // ==========================================================================
    // THEMED SCROLL PANE — scrollbar colours driven by dark/light mode
    // ==========================================================================
    private JScrollPane themedScrollPane(Component view) {
        JScrollPane sp = new JScrollPane(view);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        applyScrollBarUI(sp.getVerticalScrollBar());
        applyScrollBarUI(sp.getHorizontalScrollBar());
        return sp;
    }

    private void applyScrollBarUI(JScrollBar bar) {
        bar.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                thumbColor      = SCROLL();
                trackColor      = darkMode ? new Color(0x1E2B29) : new Color(0xDDEEED);
                thumbDarkShadowColor = BORDER();
                thumbHighlightColor  = SCROLL().brighter();
                thumbLightShadowColor = SCROLL();
            }
            @Override protected JButton createDecreaseButton(int o) { return zeroBtn(); }
            @Override protected JButton createIncreaseButton(int o) { return zeroBtn(); }
            private JButton zeroBtn() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                b.setMinimumSize(new Dimension(0, 0));
                b.setMaximumSize(new Dimension(0, 0));
                return b;
            }
            @Override protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(thumbColor);
                g2.fillRoundRect(r.x+2, r.y+2, r.width-4, r.height-4, 6, 6);
                g2.dispose();
            }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
                g.setColor(trackColor);
                g.fillRect(r.x, r.y, r.width, r.height);
            }
        });
        bar.setBackground(darkMode ? new Color(0x1E2B29) : new Color(0xDDEEED));
    }

    // ==========================================================================
    // THEMED TABBED PANE UI — dark tabs with correct border/bg colours
    // ==========================================================================
    class ThemedTabbedPaneUI extends BasicTabbedPaneUI {
        @Override protected void installDefaults() {
            super.installDefaults();
            tabPane.setBackground(BG());
            tabPane.setForeground(TEXT());
            shadow             = BORDER();
            darkShadow         = BORDER();
            highlight          = BORDER();
            lightHighlight     = BORDER();
            focus              = PRIMARY();
            // selectColor and selectHighlight are not available in newer Java versions;
            // we control selection colours in paintTabBackground directly.
        }
        @Override protected void paintTabBackground(Graphics g, int tp, int ti,
                int x, int y, int w, int h, boolean isSelected) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(isSelected ? TAB_SEL() : TAB_BG());
            g2.fillRoundRect(x+1, y+1, w-2, h+4, 8, 8);
            g2.dispose();
        }
        @Override protected void paintTabBorder(Graphics g, int tp, int ti,
                int x, int y, int w, int h, boolean isSelected) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(isSelected ? PRIMARY() : BORDER());
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawRoundRect(x+1, y+1, w-2, h+3, 8, 8);
            g2.dispose();
        }
        @Override protected void paintContentBorder(Graphics g, int tp, int si) {
            // Draw a single-pixel border around the content area matching theme
            Insets ins = tabPane.getInsets();
            int x  = ins.left,          y  = ins.top + calculateTabAreaHeight(tp, runCount, maxTabHeight) - 1;
            int w  = tabPane.getWidth() - ins.right  - ins.left;
            int h  = tabPane.getHeight()- ins.bottom - y;
            g.setColor(BORDER());
            g.drawRect(x, y, w-1, h-1);
        }
        @Override protected void paintFocusIndicator(Graphics g, int tp, Rectangle[] rects,
                int ti, Rectangle iconRect, Rectangle textRect, boolean isSelected) {}

        @Override protected int calculateTabHeight(int tp, int ti, int fh) {
            return super.calculateTabHeight(tp, ti, fh) + 4;
        }
        @Override protected void paintText(Graphics g, int tp, Font font, FontMetrics fm,
                int ti, String t, Rectangle tr, boolean isSelected) {
            g.setColor(isSelected ? (darkMode ? D_TEXT : Color.WHITE) : TEXT_MED());
            g.setFont(font);
            g.drawString(t, tr.x, tr.y + fm.getAscent());
        }
    }

    // ==========================================================================
    // UI COMPONENT HELPERS
    // ==========================================================================
    private JPanel grid() {
        JPanel p = new JPanel(new GridLayout(0, 2, 10, 10));
        p.setOpaque(false); return p;
    }

    private JPanel card(JPanel inner, String title, String iconKey) {
        JPanel w = new JPanel(new BorderLayout(0, 10)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD()); g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                g2.setColor(BORDER()); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,12,12);
                g2.dispose();
            }
        };
        w.setOpaque(false);
        w.setBorder(new EmptyBorder(12,15,15,15));
        w.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        JPanel hdr = new JPanel(new BorderLayout(7,0));
        hdr.setOpaque(false);
        hdr.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(0,0,1,0,BORDER()), new EmptyBorder(0,0,8,0)));
        JLabel lbl = new JLabel("  " + title, CIcon.cardI(iconKey, PRIMARY()), SwingConstants.LEFT);
        lbl.setFont(FNT_HEAD); lbl.setForeground(PRIMARY());
        hdr.add(lbl, BorderLayout.WEST);
        w.add(hdr, BorderLayout.NORTH);
        inner.setOpaque(false);
        w.add(inner, BorderLayout.CENTER);
        return w;
    }

    private void row(JPanel p, String lText, JComponent c) {
        JLabel l = new JLabel(lText); l.setFont(FNT_LABEL); l.setForeground(TEXT_MED());
        p.add(l); p.add(c);
    }

    private JTextField tf(String def) {
        JTextField tf = new JTextField(def) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(INPUT_BG()); g2.fillRoundRect(0,0,getWidth(),getHeight(),7,7);
                g2.dispose(); super.paintComponent(g);
            }
        };
        tf.setFont(FNT_INPUT); tf.setForeground(TEXT()); tf.setBackground(INPUT_BG()); tf.setOpaque(false);
        tf.setBorder(BorderFactory.createCompoundBorder(new RBorder(BORDER(),7), new EmptyBorder(5,9,5,9)));
        tf.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(new RBorder(PRIMARY(),7), new EmptyBorder(5,9,5,9)));
            }
            @Override public void focusLost(FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(new RBorder(BORDER(),7), new EmptyBorder(5,9,5,9)));
            }
        });
        return tf;
    }

    private void styleCombo(JComboBox<?> cb) {
        cb.setFont(FNT_INPUT); cb.setBackground(INPUT_BG()); cb.setForeground(TEXT());
    }

    private JLabel rrow(JPanel box, String label, String val, String unit) {
        JPanel row = new JPanel(new BorderLayout(6,0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        row.setBorder(new EmptyBorder(5,0,5,0));
        JLabel lbl = new JLabel(label); lbl.setFont(FNT_LABEL); lbl.setForeground(TEXT_MED());
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,4,0)); right.setOpaque(false);
        JLabel v = new JLabel(val); v.setFont(FNT_RESULT); v.setForeground(TEXT());
        JLabel u = new JLabel(unit); u.setFont(FNT_SMALL); u.setForeground(MUTED());
        right.add(v); if (!unit.isEmpty()) right.add(u);
        row.add(lbl, BorderLayout.WEST); row.add(right, BorderLayout.EAST);
        box.add(row); return v;
    }

    private JLabel rrowBold(JPanel box, String label, String val) {
        JPanel row = new JPanel(new BorderLayout(6,0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        row.setBorder(new EmptyBorder(5,0,5,0));
        JLabel lbl = new JLabel(label); lbl.setFont(new Font("Segoe UI",Font.BOLD,12)); lbl.setForeground(TEXT());
        JLabel v = new JLabel(val); v.setFont(new Font("Segoe UI",Font.BOLD,14)); v.setForeground(TEXT());
        row.add(lbl, BorderLayout.WEST); row.add(v, BorderLayout.EAST);
        box.add(row); return v;
    }

    private void capLabel(JPanel box, String text) {
        JLabel l = new JLabel(text); l.setFont(FNT_CAP); l.setForeground(TEXT_MED());
        l.setMaximumSize(new Dimension(Integer.MAX_VALUE, 22));
        l.setBorder(new EmptyBorder(0,0,2,0));
        box.add(l);
    }

    private void divLine(JPanel box) {
        box.add(gap(4));
        JPanel line = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(BORDER()); g.drawLine(0,getHeight()/2,getWidth(),getHeight()/2);
            }
        };
        line.setOpaque(false); line.setMaximumSize(new Dimension(Integer.MAX_VALUE, 8));
        box.add(line); box.add(gap(4));
    }

    private JButton pill(String text, Color bg, Color fg) {
        return pill(text, bg, fg, null);
    }

    private JButton pill(String text, Color bg, Color fg, Icon icon) {
        JButton b = new JButton(text, icon) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground()); g2.fillRoundRect(0,0,getWidth(),getHeight(),10,10);
                g2.dispose(); super.paintComponent(g);
            }
        };
        b.setFont(FNT_HEAD); b.setBackground(bg); b.setForeground(fg);
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setContentAreaFilled(false); b.setOpaque(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(9,16,9,16)); b.setIconTextGap(7);
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(bg.darker()); }
            @Override public void mouseExited(MouseEvent e)  { b.setBackground(bg); }
        });
        return b;
    }

    private void aboutDivider(JPanel card, String txt) {
        JPanel row = new JPanel(new BorderLayout(10,0));
        row.setOpaque(false); row.setMaximumSize(new Dimension(540,18));
        row.setAlignmentX(CENTER_ALIGNMENT);
        JPanel ll = line(), rl = line();
        JLabel lb = new JLabel(txt); lb.setFont(FNT_CAP); lb.setForeground(MUTED());
        row.add(ll,BorderLayout.WEST); row.add(lb,BorderLayout.CENTER); row.add(rl,BorderLayout.EAST);
        card.add(row);
    }

    private JPanel line() {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(BORDER()); g.drawLine(0,getHeight()/2,getWidth(),getHeight()/2);
            }
        };
        p.setOpaque(false); return p;
    }

    private JLabel cLabel(String text, Font font, Color color) {
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setFont(font); l.setForeground(color); l.setAlignmentX(CENTER_ALIGNMENT); return l;
    }

    private Component gap(int h) { return Box.createVerticalStrut(h); }

    // ==========================================================================
    // ICON FACTORY — pure Java2D
    // ==========================================================================
    static class CIcon {
        static Icon slab(Color c, int sz) {
            return new Icon() {
                @Override public int getIconWidth()  { return sz; }
                @Override public int getIconHeight() { return sz; }
                @Override public void paintIcon(Component comp, Graphics g, int x, int y) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    int s = sz;
                    g2.setColor(c);
                    g2.fillRoundRect(x+s/8, y+s*17/24, s*6/8, s*6/24, 3, 3);
                    g2.setColor(c.darker());
                    g2.setStroke(new BasicStroke(Math.max(1,s/20f)));
                    g2.drawLine(x+s/3,  y+s*17/24, x+s/3,  y+s*23/24);
                    g2.drawLine(x+s*2/3,y+s*17/24, x+s*2/3,y+s*23/24);
                    g2.drawLine(x+s/8,  y+s*20/24, x+s*7/8,y+s*20/24);
                    g2.setColor(c);
                    g2.fillRect(x+s/5, y+s*9/24, s*3/5, s*7/24);
                    int[] xs = {x+s/8, x+s/2, x+s*7/8};
                    int[] ys = {y+s*9/24, y+s*2/24, y+s*9/24};
                    g2.fillPolygon(xs, ys, 3);
                    g2.dispose();
                }
            };
        }

        static Icon check(Color c, int sz) {
            return new Icon() {
                @Override public int getIconWidth()  { return sz; }
                @Override public int getIconHeight() { return sz; }
                @Override public void paintIcon(Component comp, Graphics g, int x, int y) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(c); g2.fillOval(x,y,sz-1,sz-1);
                    g2.setColor(Color.WHITE);
                    g2.setStroke(new BasicStroke(Math.max(1.4f,sz/8f),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                    g2.drawLine(x+sz/5, y+sz/2, x+sz*2/5, y+sz*3/4);
                    g2.drawLine(x+sz*2/5, y+sz*3/4, x+sz*4/5, y+sz/4);
                    g2.dispose();
                }
            };
        }

        static Icon tab(String type, Color c) {
            return new Icon() {
                @Override public int getIconWidth()  { return 16; }
                @Override public int getIconHeight() { return 16; }
                @Override public void paintIcon(Component comp, Graphics g, int x, int y) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(c);
                    g2.setStroke(new BasicStroke(1.55f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                    switch(type) {
                        case "calc":
                            g2.drawRoundRect(x+1,y+1,13,13,3,3);
                            g2.drawLine(x+4,y+5,x+11,y+5);
                            g2.drawLine(x+4,y+8,x+7,y+8); g2.drawLine(x+5,y+7,x+5,y+9);
                            g2.drawLine(x+9,y+8,x+11,y+8);
                            g2.drawLine(x+4,y+11,x+7,y+11);
                            g2.drawLine(x+9,y+10,x+11,y+12); g2.drawLine(x+11,y+10,x+9,y+12);
                            break;
                        case "hist":
                            g2.drawOval(x+1,y+1,13,13);
                            g2.drawLine(x+7,y+4,x+7,y+8); g2.drawLine(x+7,y+8,x+11,y+8);
                            break;
                        case "info":
                            g2.drawOval(x+1,y+1,13,13);
                            g2.fillOval(x+6,y+4,3,3);
                            g2.drawLine(x+7,y+8,x+7,y+12);
                            break;
                    }
                    g2.dispose();
                }
            };
        }

        static Icon cardI(String type, Color c) {
            return new Icon() {
                @Override public int getIconWidth()  { return 15; }
                @Override public int getIconHeight() { return 15; }
                @Override public void paintIcon(Component comp, Graphics g, int x, int y) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(c);
                    g2.setStroke(new BasicStroke(1.55f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                    switch(type) {
                        case "proj":
                            g2.drawRoundRect(x+2,y+2,11,12,2,2);
                            g2.drawLine(x+5,y+5,x+10,y+5); g2.drawLine(x+5,y+8,x+10,y+8); g2.drawLine(x+5,y+11,x+8,y+11);
                            g2.fillRoundRect(x+5,y+1,5,2,2,2);
                            break;
                        case "ruler":
                            g2.drawRoundRect(x+1,y+5,13,5,2,2);
                            g2.drawLine(x+4,y+5,x+4,y+7); g2.drawLine(x+7,y+5,x+7,y+6);
                            g2.drawLine(x+10,y+5,x+10,y+7); g2.drawLine(x+13,y+5,x+13,y+6);
                            break;
                        case "labor":
                            g2.fillOval(x+5,y+1,5,5);
                            g2.drawArc(x+1,y+8,13,6,0,180);
                            break;
                        case "dollar":
                            g2.drawOval(x+1,y+1,12,12);
                            g2.drawLine(x+7,y+3,x+7,y+12);
                            g2.drawArc(x+4,y+5,6,3,0,180); g2.drawArc(x+4,y+7,6,3,180,180);
                            break;
                    }
                    g2.dispose();
                }
            };
        }

        static Icon summI(Color c) {
            return new Icon() {
                @Override public int getIconWidth()  { return 16; }
                @Override public int getIconHeight() { return 16; }
                @Override public void paintIcon(Component comp, Graphics g, int x, int y) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(c);
                    g2.setStroke(new BasicStroke(1.6f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                    g2.drawRoundRect(x+1,y+1,14,14,3,3);
                    g2.drawLine(x+4,y+5,x+12,y+5); g2.drawLine(x+4,y+8,x+12,y+8); g2.drawLine(x+4,y+11,x+9,y+11);
                    g2.dispose();
                }
            };
        }

        static Icon calcI(Color c)    { return btnI(c,"calc"); }
        static Icon saveI(Color c)    { return btnI(c,"save"); }
        static Icon clearI(Color c)   { return btnI(c,"clear"); }
        static Icon refreshI(Color c) { return btnI(c,"refresh"); }
        static Icon importI(Color c)  { return btnI(c,"import"); }

        private static Icon btnI(Color c, String type) {
            return new Icon() {
                @Override public int getIconWidth()  { return 13; }
                @Override public int getIconHeight() { return 13; }
                @Override public void paintIcon(Component comp, Graphics g, int x, int y) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(c);
                    g2.setStroke(new BasicStroke(1.55f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                    switch(type) {
                        case "calc":
                            g2.drawRoundRect(x+1,y+1,11,11,2,2);
                            g2.drawLine(x+4,y+4,x+9,y+4);
                            g2.drawLine(x+4,y+7,x+6,y+7); g2.drawLine(x+5,y+6,x+5,y+8);
                            g2.drawLine(x+8,y+7,x+10,y+7);
                            g2.drawLine(x+4,y+10,x+6,y+10);
                            g2.drawLine(x+8,y+9,x+10,y+11); g2.drawLine(x+10,y+9,x+8,y+11);
                            break;
                        case "save":
                            g2.drawRoundRect(x+1,y+1,11,11,2,2);
                            g2.drawRect(x+3,y+1,5,3);
                            g2.drawLine(x+3,y+7,x+10,y+7); g2.drawLine(x+3,y+9,x+10,y+9); g2.drawLine(x+3,y+11,x+8,y+11);
                            break;
                        case "clear":
                            g2.setStroke(new BasicStroke(1.9f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                            g2.drawLine(x+2,y+2,x+11,y+11); g2.drawLine(x+11,y+2,x+2,y+11);
                            break;
                        case "refresh":
                            g2.drawArc(x+2,y+2,9,9,45,270);
                            g2.drawLine(x+9,y+2,x+11,y+5); g2.drawLine(x+11,y+5,x+8,y+6);
                            break;
                        case "import":
                            // Arrow pointing down into a box = import
                            g2.drawRoundRect(x+1,y+7,11,5,2,2);
                            g2.drawLine(x+6,y+1,x+6,y+7);
                            g2.drawLine(x+3,y+5,x+6,y+8); g2.drawLine(x+9,y+5,x+6,y+8);
                            break;
                    }
                    g2.dispose();
                }
            };
        }
    }

    // ==========================================================================
    // ROUNDED BORDER
    // ==========================================================================
    static class RBorder extends AbstractBorder {
        private final Color color; private final int r;
        RBorder(Color color, int r) { this.color=color; this.r=r; }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D)g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color); g2.drawRoundRect(x,y,w-1,h-1,r,r); g2.dispose();
        }
        @Override public Insets getBorderInsets(Component c) { return new Insets(1,1,1,1); }
    }

    // ==========================================================================
    // DARK MODE TOGGLE — palette-aware pill
    // ==========================================================================
    static class DarkToggle extends JToggleButton {
        DarkToggle(boolean initialState) {
            setSelected(initialState);
            setFocusPainted(false); setBorderPainted(false); setContentAreaFilled(false);
            setOpaque(false); setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setPreferredSize(new Dimension(50, 24));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            boolean on = isSelected();
            // Track — use palette colours: ON = dark teal (D_BORDER), OFF = muted steel blue
            g2.setColor(on ? new Color(0x3C474B) : new Color(0x4F7CAC));
            g2.fillRoundRect(0, 2, 48, 18, 18, 18);
            // Thumb
            int tx = on ? 27 : 3;
            g2.setColor(new Color(0xC0E0DE));
            g2.fillOval(tx, 4, 15, 15);
            g2.setStroke(new BasicStroke(1.2f));
            if (on) {
                // Moon
                g2.setColor(new Color(0x162521));
                g2.fillOval(tx+3,6,9,9);
                g2.setColor(new Color(0xC0E0DE));
                g2.fillOval(tx+5,6,8,8);
            } else {
                // Sun — accent colour
                g2.setColor(new Color(0xFF4000));
                int cx=tx+7, cy=11;
                g2.fillOval(cx-3,cy-3,6,6);
                for(int i=0;i<8;i++){
                    double a=Math.PI*2*i/8;
                    int x1=(int)(cx+5*Math.cos(a)), y1=(int)(cy+5*Math.sin(a));
                    int x2=(int)(cx+7*Math.cos(a)), y2=(int)(cy+7*Math.sin(a));
                    g2.drawLine(x1,y1,x2,y2);
                }
            }
            g2.dispose();
        }
    }
}
