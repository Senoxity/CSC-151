package com.concrete.service;

import com.concrete.model.Project;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles CSV file integration.
 * All files are written to / read from the "imports_exports" sub-directory
 * located next to the running JAR (or in the working directory when running
 * from source).
 */
public class CsvService {

    // Sub-directory name — created automatically on first use
    private static final String IO_DIR = "imports_exports";

    private static final String ESTIMATES_FILE = "estimates.csv";
    private static final String LABOR_LOG_FILE  = "labor_log.csv";

    private static final String ESTIMATES_HEADER =
        "Date,ProjectName,Location,ClientName,SlabType," +
        "LengthFt,WidthFt,ThicknessIn,WastePct,AreaSqFt,VolumeCuYd," +
        "Employees,HrsPerEmployee,TotalLaborHrs,LaborRate," +
        "ConcreteCostPerCuYd,ConcreteMaterialCost,LaborCost," +
        "DiscountPct,FixedDiscount,DiscountAmount,TotalCost";

    private static final String LABOR_HEADER =
        "Date,ProjectName,Employees,HoursPerEmployee,TotalManpowerHours,LaborRate,TotalLaborCost";

    // -----------------------------------------------------------------------
    // Directory helpers
    // -----------------------------------------------------------------------

    /** Returns the imports_exports directory path, creating it if needed. */
    private Path ioDir() throws IOException {
        Path dir = Paths.get(IO_DIR);
        if (!Files.exists(dir)) Files.createDirectories(dir);
        return dir;
    }

    private Path estimatesPath() throws IOException { return ioDir().resolve(ESTIMATES_FILE); }
    private Path laborLogPath()  throws IOException { return ioDir().resolve(LABOR_LOG_FILE);  }

    // -----------------------------------------------------------------------
    // Save estimate to CSV
    // -----------------------------------------------------------------------
    public void saveEstimate(Project p) throws IOException {
        Path path = estimatesPath();
        boolean fileExists = Files.exists(path);
        try (PrintWriter pw = new PrintWriter(new FileWriter(path.toFile(), true))) {
            if (!fileExists) pw.println(ESTIMATES_HEADER);
            pw.printf("%s,%s,%s,%s,%s,%.2f,%.2f,%.2f,%.2f,%.2f,%.4f,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f%n",
                timestamp(),
                csvEscape(p.getProjectName()),
                csvEscape(p.getLocation()),
                csvEscape(p.getClientName()),
                p.getSlabType().getDisplayName(),
                p.getLengthFt(), p.getWidthFt(),
                p.getThicknessInches(), p.getWastePercentage(),
                p.getAreaSqFt(), p.getVolumeCubicYards(),
                p.getNumberOfEmployees(), p.getHoursPerEmployee(),
                p.getTotalLaborHours(), p.getLaborRatePerHour(),
                p.getConcreteCostPerCubicYard(),
                p.getConcreteMaterialCost(), p.getLaborCost(),
                p.getDiscountPercentage(), p.getFixedDiscount(),
                p.getDiscountAmount(), p.getTotalProjectCost()
            );
        }
    }

    // -----------------------------------------------------------------------
    // Save labor log entry
    // -----------------------------------------------------------------------
    public void saveLaborLog(Project p) throws IOException {
        Path path = laborLogPath();
        boolean fileExists = Files.exists(path);
        try (PrintWriter pw = new PrintWriter(new FileWriter(path.toFile(), true))) {
            if (!fileExists) pw.println(LABOR_HEADER);
            pw.printf("%s,%s,%d,%.2f,%.2f,%.2f,%.2f%n",
                timestamp(),
                csvEscape(p.getProjectName()),
                p.getNumberOfEmployees(),
                p.getHoursPerEmployee(),
                p.getTotalLaborHours(),
                p.getLaborRatePerHour(),
                p.getLaborCost()
            );
        }
    }

    // -----------------------------------------------------------------------
    // Load estimates from the default estimates.csv
    // -----------------------------------------------------------------------
    public List<String[]> loadEstimates() throws IOException {
        try {
            return loadFromFile(estimatesPath().toFile());
        } catch (IOException ex) {
            return new ArrayList<>();
        }
    }

    // -----------------------------------------------------------------------
    // Import estimates from any user-selected CSV file.
    // Rows that match the expected column count (22) are returned.
    // Rows whose first column looks like a header row are skipped.
    // -----------------------------------------------------------------------
    public List<String[]> importEstimatesFromFile(File file) throws IOException {
        return loadFromFile(file);
    }

    // -----------------------------------------------------------------------
    // Generic CSV loader — skips the first header row
    // -----------------------------------------------------------------------
    private List<String[]> loadFromFile(File file) throws IOException {
        List<String[]> rows = new ArrayList<>();
        if (!file.exists()) return rows;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean first = true;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                if (first) {
                    first = false;
                    // Always skip what looks like a header (starts with "Date" or "date")
                    if (line.trim().toLowerCase().startsWith("date")) continue;
                }
                rows.add(parseCsvLine(line));
            }
        }
        return rows;
    }

    // -----------------------------------------------------------------------
    // Load labor log rows
    // -----------------------------------------------------------------------
    public List<String[]> loadLaborLog() throws IOException {
        try {
            Path path = laborLogPath();
            List<String[]> rows = new ArrayList<>();
            if (!Files.exists(path)) return rows;
            try (BufferedReader br = new BufferedReader(new FileReader(path.toFile()))) {
                String line;
                boolean first = true;
                while ((line = br.readLine()) != null) {
                    if (first) { first = false; continue; }
                    rows.add(parseCsvLine(line));
                }
            }
            return rows;
        } catch (IOException ex) {
            return new ArrayList<>();
        }
    }

    // -----------------------------------------------------------------------
    // File path accessors (for display in the UI)
    // -----------------------------------------------------------------------
    public String getEstimatesFilePath() {
        try { return estimatesPath().toAbsolutePath().toString(); }
        catch (IOException e) { return IO_DIR + "/" + ESTIMATES_FILE; }
    }

    public String getLaborLogFilePath() {
        try { return laborLogPath().toAbsolutePath().toString(); }
        catch (IOException e) { return IO_DIR + "/" + LABOR_LOG_FILE; }
    }

    public String getIoDirPath() {
        try { return ioDir().toAbsolutePath().toString(); }
        catch (IOException e) { return IO_DIR; }
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------
    private String timestamp() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    private String csvEscape(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n"))
            return "\"" + value.replace("\"", "\"\"") + "\"";
        return value;
    }

    /**
     * Simple CSV line parser that respects double-quoted fields.
     */
    private String[] parseCsvLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuote = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (inQuote) {
                if (c == '"' && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    cur.append('"'); i++;
                } else if (c == '"') {
                    inQuote = false;
                } else {
                    cur.append(c);
                }
            } else {
                if (c == '"') {
                    inQuote = true;
                } else if (c == ',') {
                    fields.add(cur.toString()); cur.setLength(0);
                } else {
                    cur.append(c);
                }
            }
        }
        fields.add(cur.toString());
        return fields.toArray(new String[0]);
    }
}
