package com.concrete.model;

/**
 * Represents a concrete pad construction project estimate.
 */
public class Project {

    // Slab type presets
    public enum SlabType {
        RESIDENTIAL_PAD("Residential Pad", 4.0, 125.0),
        COMMERCIAL_PAD("Commercial Pad", 5.0, 140.0),
        WAREHOUSE_SLAB("Warehouse Slab", 6.0, 155.0),
        DRIVEWAY("Driveway", 4.0, 120.0),
        SIDEWALK("Sidewalk", 3.5, 110.0),
        CUSTOM("Custom", 4.0, 130.0);

        private final String displayName;
        private final double defaultThicknessInches;
        private final double defaultCostPerCubicYard;

        SlabType(String displayName, double defaultThicknessInches, double defaultCostPerCubicYard) {
            this.displayName = displayName;
            this.defaultThicknessInches = defaultThicknessInches;
            this.defaultCostPerCubicYard = defaultCostPerCubicYard;
        }

        public String getDisplayName() { return displayName; }
        public double getDefaultThicknessInches() { return defaultThicknessInches; }
        public double getDefaultCostPerCubicYard() { return defaultCostPerCubicYard; }

        @Override
        public String toString() { return displayName; }
    }

    // Project details
    private String projectName;
    private String location;
    private String clientName;
    private String projectDate;
    private SlabType slabType;

    // Work area
    private double lengthFt;
    private double widthFt;
    private double thicknessInches;
    private double wastePercentage;

    // Labor
    private int numberOfEmployees;
    private double hoursPerEmployee;
    private double laborRatePerHour;

    // Costs
    private double concreteCostPerCubicYard;
    private double discountPercentage;
    private double fixedDiscount;

    // ---- Calculated fields ----
    public double getAreaSqFt() {
        return lengthFt * widthFt;
    }

    public double getVolumeCubicFt() {
        double baseVolume = getAreaSqFt() * (thicknessInches / 12.0);
        return baseVolume * (1 + wastePercentage / 100.0);
    }

    public double getVolumeCubicYards() {
        return getVolumeCubicFt() / 27.0;
    }

    public double getTotalLaborHours() {
        return numberOfEmployees * hoursPerEmployee;
    }

    public double getLaborCost() {
        return getTotalLaborHours() * laborRatePerHour;
    }

    public double getConcreteMaterialCost() {
        return getVolumeCubicYards() * concreteCostPerCubicYard;
    }

    public double getSubtotal() {
        return getConcreteMaterialCost() + getLaborCost();
    }

    public double getDiscountAmount() {
        double pctDiscount = getSubtotal() * (discountPercentage / 100.0);
        return pctDiscount + fixedDiscount;
    }

    public double getTotalProjectCost() {
        return getSubtotal() - getDiscountAmount();
    }

    // ---- Getters & Setters ----
    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getClientName() { return clientName; }
    public void setClientName(String clientName) { this.clientName = clientName; }

    public String getProjectDate() { return projectDate; }
    public void setProjectDate(String projectDate) { this.projectDate = projectDate; }

    public SlabType getSlabType() { return slabType; }
    public void setSlabType(SlabType slabType) { this.slabType = slabType; }

    public double getLengthFt() { return lengthFt; }
    public void setLengthFt(double lengthFt) { this.lengthFt = lengthFt; }

    public double getWidthFt() { return widthFt; }
    public void setWidthFt(double widthFt) { this.widthFt = widthFt; }

    public double getThicknessInches() { return thicknessInches; }
    public void setThicknessInches(double thicknessInches) { this.thicknessInches = thicknessInches; }

    public double getWastePercentage() { return wastePercentage; }
    public void setWastePercentage(double wastePercentage) { this.wastePercentage = wastePercentage; }

    public int getNumberOfEmployees() { return numberOfEmployees; }
    public void setNumberOfEmployees(int numberOfEmployees) { this.numberOfEmployees = numberOfEmployees; }

    public double getHoursPerEmployee() { return hoursPerEmployee; }
    public void setHoursPerEmployee(double hoursPerEmployee) { this.hoursPerEmployee = hoursPerEmployee; }

    public double getLaborRatePerHour() { return laborRatePerHour; }
    public void setLaborRatePerHour(double laborRatePerHour) { this.laborRatePerHour = laborRatePerHour; }

    public double getConcreteCostPerCubicYard() { return concreteCostPerCubicYard; }
    public void setConcreteCostPerCubicYard(double concreteCostPerCubicYard) { this.concreteCostPerCubicYard = concreteCostPerCubicYard; }

    public double getDiscountPercentage() { return discountPercentage; }
    public void setDiscountPercentage(double discountPercentage) { this.discountPercentage = discountPercentage; }

    public double getFixedDiscount() { return fixedDiscount; }
    public void setFixedDiscount(double fixedDiscount) { this.fixedDiscount = fixedDiscount; }
}
