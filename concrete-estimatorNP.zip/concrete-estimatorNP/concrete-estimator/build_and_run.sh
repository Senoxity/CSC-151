#!/bin/bash
# ============================================================
#  Concrete Pad Estimator — Build & Run Script (Mac/Linux)
#  Requirements: Java JDK 11+ installed
#  Install JDK: https://adoptium.net/
# ============================================================

echo "==> Compiling Concrete Pad Estimator..."
mkdir -p out

javac -d out \
  src/main/java/com/concrete/model/Project.java \
  src/main/java/com/concrete/service/CsvService.java \
  src/main/java/com/concrete/ui/EstimatorApp.java \
  src/main/java/com/concrete/Main.java

if [ $? -ne 0 ]; then
  echo ""
  echo "ERROR: Compilation failed. Make sure Java JDK 11+ is installed."
  echo "Install from: https://adoptium.net/"
  exit 1
fi

echo "==> Compilation successful!"
echo ""
echo "==> Creating JAR..."
jar --create --file ConcreteEstimator.jar --main-class com.concrete.Main -C out .

echo ""
echo "==> Launching application..."
java -jar ConcreteEstimator.jar
