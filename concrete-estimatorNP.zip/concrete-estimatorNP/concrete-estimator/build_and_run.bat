@echo off
setlocal EnableDelayedExpansion

title Concrete Pad Estimator — Build ^& Launch

echo.
echo  =====================================================
echo   Concrete Pad Construction Estimator — Launcher
echo  =====================================================
echo.

REM ── 1. Verify Java is installed ──────────────────────────────────────────
where javac >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo  [ERROR] Java JDK not found on PATH.
    echo.
    echo  Please install Java JDK 11 or newer from:
    echo    https://adoptium.net/
    echo.
    echo  After installing, re-open this window and run again.
    echo.
    pause
    exit /b 1
)

echo  [OK] Java found:
java -version 2>&1 | findstr /i "version"
echo.

REM ── 2. Compile if needed ────────────────────────────────────────────────
set "JARFILE=ConcreteEstimator.jar"
set "REBUILD=0"

if not exist "%JARFILE%" set "REBUILD=1"

REM Force rebuild if any source file is newer than the JAR
if exist "%JARFILE%" (
    for /f %%F in ('dir /b /s /o:-d src\main\java\com\concrete\*.java 2^>nul') do (
        for /f %%A in ('xcopy /L /D /Y "%%F" "%JARFILE%" 2^>nul ^| find /c "File"') do (
            if "%%A"=="1" set "REBUILD=1"
        )
    )
)

if "!REBUILD!"=="1" (
    echo  [BUILD] Compiling source files...
    if not exist out mkdir out

    javac -d out ^
      src\main\java\com\concrete\model\Project.java ^
      src\main\java\com\concrete\service\CsvService.java ^
      src\main\java\com\concrete\ui\EstimatorApp.java ^
      src\main\java\com\concrete\Main.java

    if !ERRORLEVEL! neq 0 (
        echo.
        echo  [ERROR] Compilation failed. Check the error messages above.
        echo.
        pause
        exit /b 1
    )

    echo  [BUILD] Creating JAR...
    jar --create --file "%JARFILE%" --main-class com.concrete.Main -C out .

    if !ERRORLEVEL! neq 0 (
        echo.
        echo  [ERROR] Failed to create JAR. Is JDK 11+ installed?
        echo.
        pause
        exit /b 1
    )

    echo  [OK] Build successful.
    echo.
) else (
    echo  [OK] JAR is up-to-date. Skipping compilation.
    echo.
)

REM ── 3. Launch the application (javaw = no console window needed by app) ─
echo  [LAUNCH] Starting Concrete Pad Estimator...
echo  [INFO]   Close this window after the app opens, or keep it for logs.
echo.

REM Use START /WAIT so this window stays open while the app runs.
REM Replace START /WAIT with plain "javaw" to close this window immediately.
start "Concrete Pad Estimator" /WAIT java -jar "%JARFILE%"

echo.
echo  [INFO] Application closed.
echo.
pause
endlocal
