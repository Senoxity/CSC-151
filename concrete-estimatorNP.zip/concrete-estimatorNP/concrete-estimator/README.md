# 🏗️ Concrete Pad Construction Estimator

A Java Swing desktop application for calculating and generating estimates for concrete pad construction projects.

---

## Features

### Core Features
- **Project Details** — Enter project name, location, client name, date
- **Slab Type Presets** — Residential Pad, Commercial Pad, Warehouse Slab, Driveway, Sidewalk, Custom
- **Work Area Calculations** — Length × Width area + volume from slab thickness (cu yd)
- **Waste Percentage** — Adds configurable waste factor to concrete volume
- **Labor Estimation** — Number of employees × hours/employee = total labor hours & cost
- **Cost Breakdown** — Concrete material cost, labor cost, subtotal, discount, and grand total
- **Discount System** — Both percentage discount and fixed dollar discount supported

### CSV Integration
- **estimates.csv** — Full project record saved on each estimate (all fields)
- **labor_log.csv** — Manpower hours & work hours log
- **Saved Estimates Tab** — View all past estimates in a scrollable table within the app

---

## Requirements

- Java JDK 11 or higher  
- Download from: https://adoptium.net/

Check your Java version:
```
java -version
```

---

## Build & Run

### Windows
```bat
build_and_run.bat
```

### Mac / Linux
```bash
chmod +x build_and_run.sh
./build_and_run.sh
```

### Run pre-built JAR (after building once)
```bash
java -jar ConcreteEstimator.jar
```

---

## Project Structure

```
concrete-estimator/
├── src/main/java/com/concrete/
│   ├── Main.java                    ← Entry point
│   ├── model/
│   │   └── Project.java             ← Data model + calculations
│   ├── service/
│   │   └── CsvService.java          ← CSV read/write
│   └── ui/
│       └── EstimatorApp.java        ← Swing GUI
├── build_and_run.bat               ← Windows build script
├── build_and_run.sh                ← Mac/Linux build script
└── README.md
```

---

## CSV Output Format

### estimates.csv
`Date, ProjectName, Location, ClientName, SlabType, LengthFt, WidthFt, ThicknessIn, WastePct, AreaSqFt, VolumeCuYd, Employees, HrsPerEmployee, TotalLaborHrs, LaborRate, ConcreteCostPerCuYd, ConcreteMaterialCost, LaborCost, DiscountPct, FixedDiscount, DiscountAmount, TotalCost`

### labor_log.csv
`Date, ProjectName, Employees, HoursPerEmployee, TotalManpowerHours, LaborRate, TotalLaborCost`

---

## Slab Type Defaults

| Slab Type        | Thickness (in) | Concrete ($/cu yd) |
|------------------|---------------|---------------------|
| Residential Pad  | 4.0           | $125.00             |
| Commercial Pad   | 5.0           | $140.00             |
| Warehouse Slab   | 6.0           | $155.00             |
| Driveway         | 4.0           | $120.00             |
| Sidewalk         | 3.5           | $110.00             |
| Custom           | 4.0           | $130.00             |
